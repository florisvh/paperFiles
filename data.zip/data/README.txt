Column 'sex': 	
1=Male
2=Female


Column 'education':
1=No high school diploma
2=High school diploma
3=Intermediate vocational education (MBO)
4=Associate degree
5=Bachelor's degree
6=Master's degree
7=Professional degree
8=Doctorate degree

Column 'survivalChance'
0= Without survival chances displayed
1= With survival chances displayed

Columns 'sim1'...'sim13':
1= Keep straight
2= Turn
EXCEPTION 'sim9'& 'sim10' :
1=Keep straight
2= Turn left
3= Turn right