-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Gegenereerd op: 27 jun 2019 om 21:52
-- Serverversie: 10.3.14-MariaDB
-- PHP-versie: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id8214654_ximpel1`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `ximpeldata`
--

CREATE TABLE `ximpeldata` (
  `id` int(11) NOT NULL,
  `age` int(11) NOT NULL,
  `sex` int(11) NOT NULL,
  `education` int(11) NOT NULL,
  `sim1` int(11) NOT NULL,
  `sim2` int(11) NOT NULL,
  `sim3` int(11) NOT NULL,
  `sim4` int(11) NOT NULL,
  `sim5` int(11) NOT NULL,
  `sim6` int(11) NOT NULL,
  `sim7` int(11) NOT NULL,
  `sim8` int(11) NOT NULL,
  `sim9` int(11) NOT NULL,
  `sim10` int(11) NOT NULL,
  `sim11` int(11) NOT NULL,
  `sim12` int(11) NOT NULL,
  `sim13` int(11) NOT NULL,
  `sim14` int(11) NOT NULL,
  `survivalChance` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `ximpeldata`
--

INSERT INTO `ximpeldata` (`id`, `age`, `sex`, `education`, `sim1`, `sim2`, `sim3`, `sim4`, `sim5`, `sim6`, `sim7`, `sim8`, `sim9`, `sim10`, `sim11`, `sim12`, `sim13`, `survivalChance`) VALUES
(7, 22, 1, 2, 2, 2, 2, 2, 2, 1, 1, 2, 3, 3, 2, 2, 2, 0),
(8, 39, 1, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 3, 2, 2, 2, 0),
(9, 22, 1, 2, 2, 1, 2, 1, 1, 1, 1, 2, 1, 2, 1, 1, 2, 0),
(10, 22, 1, 2, 1, 1, 2, 2, 1, 1, 1, 2, 1, 3, 2, 1, 2, 0),
(13, 21, 2, 2, 2, 1, 2, 2, 2, 1, 1, 2, 1, 2, 1, 2, 1, 0),
(14, 22, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 3, 3, 1, 1, 2, 0),
(16, 23, 1, 2, 2, 1, 2, 1, 1, 1, 1, 1, 3, 3, 1, 1, 2, 0),
(17, 22, 1, 2, 1, 1, 1, 2, 2, 2, 2, 2, 1, 2, 1, 2, 1, 0),
(18, 51, 1, 2, 1, 2, 1, 2, 2, 1, 2, 2, 1, 2, 2, 2, 1, 1),
(19, 53, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 3, 1, 2, 2, 1),
(21, 52, 1, 2, 2, 1, 2, 1, 1, 1, 1, 1, 3, 3, 1, 2, 2, 1),
(23, 24, 2, 2, 2, 1, 2, 1, 1, 1, 1, 2, 1, 2, 2, 1, 1, 1),
(25, 26, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 0),
(26, 54, 2, 2, 2, 2, 2, 1, 1, 1, 1, 2, 3, 3, 2, 1, 2, 0),
(27, 50, 2, 2, 2, 2, 2, 1, 1, 1, 1, 2, 3, 3, 2, 1, 2, 1),
(28, 26, 1, 2, 2, 1, 2, 1, 1, 1, 1, 1, 1, 3, 1, 1, 2, 1),
(29, 27, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 0),
(30, 21, 1, 2, 1, 1, 2, 2, 2, 1, 1, 1, 1, 2, 1, 2, 2, 1),
(31, 22, 2, 2, 2, 2, 2, 1, 1, 1, 1, 2, 3, 3, 1, 2, 2, 0),
(32, 53, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 3, 3, 1, 1, 2, 1),
(33, 23, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1),
(34, 23, 2, 2, 2, 1, 2, 1, 1, 1, 1, 1, 3, 3, 1, 2, 2, 1),
(36, 72, 3, 2, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1),
(37, 73, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 0),
(39, 22, 1, 5, 2, 2, 1, 2, 1, 1, 1, 2, 1, 3, 1, 1, 2, 1),
(40, 42, 2, 6, 2, 2, 2, 1, 1, 1, 1, 2, 1, 3, 1, 1, 2, 0),
(41, 27, 1, 6, 2, 1, 1, 2, 1, 1, 1, 2, 1, 2, 1, 2, 2, 1),
(42, 20, 1, 5, 2, 2, 2, 2, 1, 1, 1, 1, 1, 2, 2, 1, 2, 0),
(43, 24, 1, 5, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 2, 2, 1),
(44, 43, 1, 6, 2, 2, 2, 2, 1, 1, 1, 1, 1, 3, 2, 2, 2, 1),
(45, 32, 2, 5, 2, 1, 2, 1, 1, 1, 1, 2, 3, 3, 2, 1, 2, 1),
(46, 23, 1, 5, 2, 1, 2, 1, 1, 1, 1, 1, 1, 3, 1, 1, 2, 0),
(47, 56, 2, 3, 1, 1, 2, 2, 1, 1, 1, 2, 1, 3, 1, 2, 2, 0),
(48, 19, 2, 4, 2, 2, 2, 1, 1, 2, 1, 2, 1, 2, 2, 1, 2, 0),
(49, 35, 2, 5, 2, 1, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 2, 1),
(50, 60, 1, 5, 2, 1, 2, 2, 1, 1, 1, 2, 1, 3, 1, 2, 2, 0),
(51, 22, 2, 6, 1, 1, 2, 2, 1, 1, 1, 1, 3, 2, 1, 2, 2, 1),
(52, 44, 2, 3, 1, 1, 1, 2, 1, 1, 2, 2, 1, 2, 1, 2, 2, 0),
(53, 22, 2, 5, 1, 1, 1, 2, 2, 1, 2, 2, 1, 2, 1, 2, 2, 0),
(54, 25, 1, 5, 2, 1, 1, 1, 1, 1, 1, 2, 2, 3, 1, 2, 1, 1),
(55, 21, 2, 5, 2, 2, 2, 1, 1, 1, 1, 1, 3, 3, 1, 1, 2, 1);

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `ximpeldata`
--
ALTER TABLE `ximpeldata`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `ximpeldata`
--
ALTER TABLE `ximpeldata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
